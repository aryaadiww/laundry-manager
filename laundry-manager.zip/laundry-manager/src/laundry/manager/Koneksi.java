package laundry.manager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Koneksi {
    private static Connection connection;

    public static Connection getConnection() {
        JFrame frame = new JFrame();
        try {
            // Register the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/laundry_manager", "root", "");
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(frame, "JDBC Driver tidak ditemukan!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(frame, "Koneksi Error: " + e.getMessage(), "FATAL", JOptionPane.ERROR_MESSAGE);
        }
        return connection;
    }
}
