# laundrymanager
Aplikasi Laundry Manager Java Netbeans (Tubes PBO Semester 2)


# Screenshot : 
![Screenshot](work-laundry.png)
